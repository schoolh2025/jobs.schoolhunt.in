import React from "react";
const StatsSection = () => {
  return (
    <div>
      <h1>Stats Section (To be refactored or removed if not used in single-page design)</h1>
    </div>
  );
};
export default StatsSection;