import React from "react";
import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, Heart } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const CopyrightFooter = () => {
  const currentYear = new Date().getFullYear();
  
  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-slate-800 dark:bg-slate-900 text-slate-300 border-t border-slate-700">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img src="/logo.svg" alt="SarkariJobs Logo" className="h-10 w-auto" />
            </div>
            <p className="text-sm text-slate-400 mb-4">
              JOBS.SCHOOLHUNT.IN: Your trusted source for government job notifications, results, and career guidance.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, index) => (
                <motion.a 
                  key={index}
                  href="#" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  whileHover={{ y: -3, scale: 1.1 }}
                  className="text-slate-400 hover:text-primary transition-colors"
                >
                  <Icon size={20} />
                </motion.a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-md font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2.5">
              {["latest-jobs", "results", "admit-cards", "answer-keys", "syllabus"].map(id => (
                <li key={id}>
                  <button onClick={() => scrollToSection(id)} className="text-sm text-slate-400 hover:text-primary transition-colors capitalize">
                    {id.replace('-', ' ')}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-md font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Contact Us
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={18} className="text-primary mr-3 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-slate-400">
                  123 Government Street, New Delhi, India
                </span>
              </li>
              <li className="flex items-center">
                <Phone size={18} className="text-primary mr-3 flex-shrink-0" />
                <span className="text-sm text-slate-400">
                  +91 98765 43210
                </span>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="text-primary mr-3 flex-shrink-0" />
                <span className="text-sm text-slate-400">
                  info@sarkarijobs.schoolhunt.in
                </span>
              </li>
            </ul>
          </div>

           <div>
            <h3 className="text-md font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Legal
            </h3>
            <ul className="space-y-2.5">
              {["Privacy Policy", "Terms of Service", "Disclaimer"].map(text => (
                 <li key={text}>
                  <a href="#" className="text-sm text-slate-400 hover:text-primary transition-colors">
                    {text}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <Separator className="my-8 bg-slate-700" />
        
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <p className="text-sm text-slate-500 mb-4 md:mb-0">
            © {currentYear} SarkariJobs.schoolhunt.in. All rights reserved.
          </p>
          <p className="text-xs text-slate-500 flex items-center justify-center">
            Designed with <Heart size={12} className="text-red-500 mx-1.5" /> by SchoolHunt
          </p>
        </div>
      </div>
    </footer>
  );
};

export default CopyrightFooter;