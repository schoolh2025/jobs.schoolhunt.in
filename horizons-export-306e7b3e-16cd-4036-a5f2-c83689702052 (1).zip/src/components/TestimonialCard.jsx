import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const TestimonialCard = ({ testimonial, index }) => {
  return (
    <motion.div
      key={testimonial.id}
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: (index || 0) * 0.1 }}
      viewport={{ once: true }}
    >
      <Card className="glassmorphism-card card-hover h-full shadow-lg">
        <CardContent className="pt-6 flex flex-col items-center text-center h-full">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold mb-5 shadow-xl ring-4 ring-white/50 dark:ring-slate-700/50">
            {testimonial.avatar}
          </div>
          <p className="text-muted-foreground italic mb-4 flex-grow text-sm md:text-base">"{testimonial.text}"</p>
          <Separator className="my-4" />
          <p className="font-semibold text-lg text-primary">{testimonial.name}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TestimonialCard;