import React from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink, FileText, DownloadCloud } from "lucide-react";

export const DetailItemCard = ({ title, value, icon, className = "", valueClassName = "" }) => (
  <div className={`flex items-start p-3 bg-slate-100 dark:bg-slate-800 rounded-lg shadow-sm ${className}`}>
    {React.cloneElement(icon, { className: "h-6 w-6 mr-3 text-primary flex-shrink-0 mt-1" })}
    <div>
      <h4 className="text-sm font-medium text-muted-foreground">{title}</h4>
      <p className={`text-md font-semibold text-foreground ${valueClassName}`}>{value}</p>
    </div>
  </div>
);

export const LinkButtonGroup = ({ item, type, currentLabels }) => {
  const links = [];

  if (type === "job") {
    if (item.applicationLink) links.push({ href: item.applicationLink, label: currentLabels.applyNow, variant: "default", icon: <ExternalLink /> });
    if (item.shortNotificationLink) links.push({ href: item.shortNotificationLink, label: currentLabels.shortNotification, variant: "outline", icon: <FileText /> });
    if (item.fullNotificationLink) links.push({ href: item.fullNotificationLink, label: currentLabels.fullNotification, variant: "outline", icon: <FileText /> });
    if (item.pdfLink) links.push({ href: item.pdfLink, label: currentLabels.downloadPDF, variant: "secondary", icon: <DownloadCloud /> });
  } else if (type === "admit-card") {
    if (item.downloadLink) links.push({ href: item.downloadLink, label: currentLabels.downloadAdmitCard, variant: "default", icon: <DownloadCloud /> });
    if (item.link && !item.downloadLink) links.push({ href: item.link, label: currentLabels.viewSource, variant: "outline", icon: <ExternalLink /> });
  } else if (type === "result") {
    if (item.pdfLink) links.push({ href: item.pdfLink, label: currentLabels.viewResult, variant: "default", icon: <FileText /> });
    if (item.link && !item.pdfLink) links.push({ href: item.link, label: currentLabels.viewSource, variant: "outline", icon: <ExternalLink /> });
  } else { // syllabus, answer-key, notification
    if (item.pdfLink) links.push({ href: item.pdfLink, label: currentLabels.downloadPDF, variant: "default", icon: <DownloadCloud /> });
    if (item.link && !item.pdfLink) links.push({ href: item.link, label: currentLabels.viewSource, variant: "outline", icon: <ExternalLink /> });
  }


  return (
    <div className="flex flex-wrap gap-3 mb-6">
      {links.map(linkInfo => (
        <Button key={linkInfo.label} asChild className={linkInfo.variant === "default" ? "btn-primary" : linkInfo.variant === "secondary" ? "btn-secondary" : "border-primary text-primary hover:bg-primary/10"}>
          <a href={linkInfo.href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
            {linkInfo.icon && React.cloneElement(linkInfo.icon, { className: "h-4 w-4"})}
            {linkInfo.label}
          </a>
        </Button>
      ))}
    </div>
  );
};