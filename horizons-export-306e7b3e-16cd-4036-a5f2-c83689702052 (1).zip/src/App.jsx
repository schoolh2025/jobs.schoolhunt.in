import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/components/ui/use-toast";
import HomePage from "@/pages/HomePage";
import JobDetailPage from "@/pages/JobDetailPage";
import NotFoundPage from "@/pages/NotFoundPage";
import CopyrightFooter from "@/components/CopyrightFooter";
import { Menu, X, Search, Sun, Moon, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const App = () => {
  const { toast } = useToast();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");
  const [language, setLanguage] = useState(localStorage.getItem("language") || "en");

  useEffect(() => {
    const hasVisited = localStorage.getItem("hasVisitedSarkariJobs");
    if (!hasVisited) {
      toast({
        title: "Welcome to SarkariJobs.schoolhunt.in!",
        description: "Your one-stop solution for government job updates.",
        duration: 5000,
      });
      localStorage.setItem("hasVisitedSarkariJobs", "true");
    }
  }, [toast]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("theme", theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
    localStorage.setItem("language", language);
    const langChangeEvent = new CustomEvent('languageChange', { detail: language });
    window.dispatchEvent(langChangeEvent);
  }, [language]);

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const searchEvent = new CustomEvent('appSearch', { detail: searchQuery });
    window.dispatchEvent(searchEvent);
  };

  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
    setIsMenuOpen(false);
  };
  
  const navLabels = {
    en: {
      latestJobs: "Latest Jobs",
      results: "Results",
      admitCards: "Admit Cards",
      mainContent: "Main Content",
      feedback: "Feedback",
      searchPlaceholder: "Search...",
    },
    hi: {
      latestJobs: "नवीनतम नौकरियां",
      results: "परिणाम",
      admitCards: "प्रवेश पत्र",
      mainContent: "मुख्य सामग्री",
      feedback: "प्रतिक्रिया",
      searchPlaceholder: "खोजें...",
    }
  };

  const navLinks = [
    { id: "main-content-area", label: navLabels[language].mainContent },
    { id: "feedback", label: navLabels[language].feedback },
  ];

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-background text-foreground">
        <header 
          className={`sticky top-0 z-50 w-full transition-all duration-300 
            ${isScrolled ? "bg-gradient-to-r from-primary/80 to-accent/80 dark:from-slate-900/80 dark:to-neutral-900/80 backdrop-blur-md shadow-xl" : "bg-transparent pt-2 pb-1"
          }`}
        >
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between h-20 md:h-24">
              <a href="#hero" onClick={() => scrollToSection('hero')} className="flex items-center space-x-1 sm:space-x-2">
                <motion.img 
                  src="/logo.svg" 
                  alt="SarkariJobs.schoolhunt.in Logo" 
                  className="h-16 w-auto sm:h-20 md:h-24"
                  whileHover={{ rotate: [0, 2, -2, 0], scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                />
              </a>
              
              <nav className="hidden lg:flex items-center space-x-1">
                {navLinks.map(link => (
                  <Button variant="ghost" key={link.id} onClick={() => scrollToSection(link.id)} className="nav-link text-white hover:bg-white/20">
                    {link.label}
                  </Button>
                ))}
              </nav>
              
              <div className="flex items-center space-x-1 sm:space-x-2">
                <form onSubmit={handleSearch} className="hidden md:flex items-center relative">
                  <Input
                    type="text"
                    placeholder={navLabels[language].searchPlaceholder}
                    className="w-32 sm:w-40 pr-10 bg-white/30 dark:bg-slate-700/50 placeholder-white/70 dark:placeholder-slate-300/70 text-white dark:text-slate-100 rounded-full border-white/50 focus:border-white"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <Button 
                    type="submit" 
                    variant="ghost" 
                    size="icon" 
                    className="absolute right-0 text-white/80 hover:text-white"
                  >
                    <Search className="h-5 w-5" />
                  </Button>
                </form>

                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-[70px] sm:w-[80px] bg-white/30 dark:bg-slate-700/50 text-white dark:text-slate-100 border-white/50 focus:border-white">
                    <SelectValue placeholder="Lang" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">ENG</SelectItem>
                    <SelectItem value="hi">HIN</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle theme" className="text-white hover:bg-white/20">
                  {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="lg:hidden text-white hover:bg-white/20"
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  aria-label="Toggle menu"
                >
                  {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                </Button>
              </div>
            </div>
          </div>
          
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="lg:hidden bg-white/95 dark:bg-slate-800/95 backdrop-blur-md border-t border-border shadow-lg"
              >
                <div className="container mx-auto px-4 py-4">
                  <form onSubmit={handleSearch} className="mb-4 flex items-center relative">
                    <Input
                      type="text"
                      placeholder={navLabels[language].searchPlaceholder}
                      className="w-full pr-10 bg-white/80 dark:bg-slate-700/80"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <Button 
                      type="submit" 
                      variant="ghost" 
                      size="icon" 
                      className="absolute right-0 text-muted-foreground hover:text-primary"
                    >
                      <Search className="h-5 w-5" />
                    </Button>
                  </form>
                  
                  <nav className="flex flex-col space-y-2">
                    {navLinks.map(link => (
                      <Button variant="ghost" key={link.id} onClick={() => scrollToSection(link.id)} className="nav-link justify-start w-full text-lg py-3">
                        {link.label}
                      </Button>
                    ))}
                  </nav>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </header>
        
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/item/:type/:id" element={<JobDetailPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        
        <CopyrightFooter />
        <Toaster />
      </div>
    </Router>
  );
};

export default App;