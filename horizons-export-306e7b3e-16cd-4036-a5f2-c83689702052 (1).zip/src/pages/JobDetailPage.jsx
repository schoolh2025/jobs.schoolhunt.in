import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Briefcase, MapPin, GraduationCap, Clock, Users, DollarSign, Share2, Bookmark, ExternalLink, CalendarDays, Info, AlertTriangle, FileText, DownloadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";
import { jobsData } from "@/data/jobsData";
import { updatesData } from "@/data/updatesData"; 
import NotFoundPage from "@/pages/NotFoundPage";
import { DetailItemCard, LinkButtonGroup } from "@/components/JobDetailElements";

const JobDetailPage = () => {
  const { type, id } = useParams();
  const [item, setItem] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [language, setLanguage] = useState(localStorage.getItem("language") || "en");
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const handleLangChange = (event) => setLanguage(event.detail);
    window.addEventListener('languageChange', handleLangChange);
    return () => window.removeEventListener('languageChange', handleLangChange);
  }, []);

  useEffect(() => {
    setIsLoading(true);
    let foundItem;
    const itemId = parseInt(id);

    if (type === "job") {
      foundItem = jobsData.find(j => j.id === itemId);
    } else {
      foundItem = updatesData.find(u => u.id === itemId && u.type === type);
      if (!foundItem && (type === 'answer-key' || type === 'syllabus')) {
         foundItem = updatesData.find(u => u.id === itemId && (u.title.toLowerCase().includes(type.replace('-', ' '))));
      }
    }
    
    if (foundItem) {
      const itemInCurrentLang = {
        ...foundItem,
        title: language === 'hi' && foundItem.title_hi ? foundItem.title_hi : foundItem.title,
        description: language === 'hi' && foundItem.description_hi ? foundItem.description_hi : foundItem.description,
        eligibility: language === 'hi' && foundItem.eligibility_hi ? foundItem.eligibility_hi : foundItem.eligibility,
        selectionProcess: language === 'hi' && foundItem.selectionProcess_hi ? foundItem.selectionProcess_hi : foundItem.selectionProcess,
      };
      setItem(itemInCurrentLang);
      document.title = `${itemInCurrentLang.title} - SarkariJobs.schoolhunt.in`;
      const bookmarkedItems = JSON.parse(localStorage.getItem("bookmarkedItems") || "[]");
      setIsBookmarked(bookmarkedItems.some(bItem => bItem.id === itemId && bItem.type === type));
    }
    
    setIsLoading(false);
  }, [id, type, language]);

  const handleBookmark = () => {
    const itemId = parseInt(id);
    let bookmarkedItems = JSON.parse(localStorage.getItem("bookmarkedItems") || "[]");
    const originalItem = type === "job" ? jobsData.find(j => j.id === itemId) : updatesData.find(u => u.id === itemId);

    if (isBookmarked) {
      bookmarkedItems = bookmarkedItems.filter(bItem => !(bItem.id === itemId && bItem.type === type));
      setIsBookmarked(false);
      toast({ title: "Removed from bookmarks", description: "Item removed from your bookmarks." });
    } else {
      bookmarkedItems.push({ id: itemId, type, title: originalItem.title });
      setIsBookmarked(true);
      toast({ title: "Added to bookmarks", description: "Item added to your bookmarks." });
    }
    localStorage.setItem("bookmarkedItems", JSON.stringify(bookmarkedItems));
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: item.title,
        text: `Check this out: ${item.title}`,
        url: window.location.href,
      }).catch(error => console.log("Error sharing:", error));
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({ title: "Link copied!", description: "Link copied to clipboard." });
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center min-h-[calc(100vh-200px)]">
        <div className="w-16 h-16 border-4 border-t-primary border-b-secondary border-l-accent border-r-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!item) return <NotFoundPage />;

  const labels = {
    en: {
      postedDate: "Posted Date", organization: "Organization", location: "Location",
      qualification: "Qualification", lastDate: "Last Date", vacancies: "Vacancies",
      salary: "Salary", jobDescription: "Job Description", eligibilityCriteria: "Eligibility Criteria",
      selectionProcess: "Selection Process", importantDates: "Important Dates", category: "Category",
      date: "Date", details: "Details", overview: "Overview", 
      applyNow: "Apply Now", viewSource: "View Source", downloadAdmitCard: "Download Admit Card",
      viewResult: "View Result", downloadPDF: "Download PDF", shortNotification: "Short Notification", fullNotification: "Full Notification",
      bookmark: "Bookmark", bookmarked: "Bookmarked", share: "Share",
      back: "Back", disclaimer: "Disclaimer",
      disclaimerText: "SarkariJobs.schoolhunt.in is a job information portal. We gather information from various official sources and present it in an easy-to-understand format. Users are advised to verify all details from the official notification or website before applying for any job or taking any action. We are not responsible for any discrepancies or inaccuracies."
    },
    hi: {
      postedDate: "प्रकाशन तिथि", organization: "संगठन", location: "स्थान",
      qualification: "योग्यता", lastDate: "अंतिम तिथि", vacancies: "रिक्तियां",
      salary: "वेतन", jobDescription: "नौकरी का विवरण", eligibilityCriteria: "पात्रता मापदंड",
      selectionProcess: "चयन प्रक्रिया", importantDates: "महत्वपूर्ण तिथियाँ", category: "श्रेणी",
      date: "दिनांक", details: "विवरण", overview: "अवलोकन", 
      applyNow: "अभी आवेदन करें", viewSource: "स्रोत देखें", downloadAdmitCard: "प्रवेश पत्र डाउनलोड करें",
      viewResult: "परिणाम देखें", downloadPDF: "पीडीएफ डाउनलोड करें", shortNotification: "संक्षिप्त अधिसूचना", fullNotification: "पूर्ण अधिसूचना",
      bookmark: "बुकमार्क करें", bookmarked: "बुकमार्क किया गया", share: "साझा करें",
      back: "वापस", disclaimer: "अस्वीकरण",
      disclaimerText: "SarkariJobs.schoolhunt.in एक नौकरी सूचना पोर्टल है। हम विभिन्न आधिकारिक स्रोतों से जानकारी एकत्र करते हैं और इसे समझने में आसान प्रारूप में प्रस्तुत करते हैं। उपयोगकर्ताओं को सलाह दी जाती है कि वे किसी भी नौकरी के लिए आवेदन करने या कोई कार्रवाई करने से पहले आधिकारिक अधिसूचना या वेबसाइट से सभी विवरणों की पुष्टि करें। हम किसी भी विसंगति या अशुद्धि के लिए जिम्मेदार नहीं हैं।"
    }
  };
  const currentLabels = labels[language];
  
  let startDate = item.postedDate || (item.importantDates && item.importantDates.applicationStart) || item.date;

  const commonDetails = [
    { title: currentLabels.postedDate, value: startDate, icon: <CalendarDays />, valueClassName: "text-green-600 dark:text-green-400" },
    { title: currentLabels.organization, value: item.organization, icon: <Briefcase /> },
    { title: currentLabels.location, value: item.location, icon: <MapPin /> },
  ];

  const jobSpecificDetails = [
    { title: currentLabels.qualification, value: item.qualification, icon: <GraduationCap /> },
    { title: currentLabels.lastDate, value: item.lastDate || (item.importantDates && item.importantDates.applicationEnd), icon: <Clock />, valueClassName: "text-red-600 dark:text-red-400" },
    { title: currentLabels.vacancies, value: item.vacancies, icon: <Users /> },
    { title: currentLabels.salary, value: item.salary, icon: <DollarSign /> },
  ];
  
  const renderContent = () => {
    switch (type) {
      case "job":
        return (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              {commonDetails.filter(d => d.value).map(detail => <DetailItemCard key={detail.title} {...detail} />)}
              {jobSpecificDetails.filter(d => d.value).map(detail => <DetailItemCard key={detail.title} {...detail} />)}
            </div>
            <Card className="mb-6 glassmorphism-card">
              <CardHeader><CardTitle className="gradient-text">{currentLabels.jobDescription}</CardTitle></CardHeader>
              <CardContent><p className="text-foreground/80 whitespace-pre-line">{item.description}</p></CardContent>
            </Card>
            {item.eligibility && (
              <Card className="mb-6 glassmorphism-card">
                <CardHeader><CardTitle className="gradient-text">{currentLabels.eligibilityCriteria}</CardTitle></CardHeader>
                <CardContent><p className="text-foreground/80 whitespace-pre-line">{item.eligibility}</p></CardContent>
              </Card>
            )}
            {item.selectionProcess && (
              <Card className="mb-6 glassmorphism-card">
                <CardHeader><CardTitle className="gradient-text">{currentLabels.selectionProcess}</CardTitle></CardHeader>
                <CardContent><p className="text-foreground/80 whitespace-pre-line">{item.selectionProcess}</p></CardContent>
              </Card>
            )}
            {item.importantDates && (
              <Card className="glassmorphism-card">
                <CardHeader><CardTitle className="gradient-text">{currentLabels.importantDates}</CardTitle></CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {Object.entries(item.importantDates).map(([key, value]) => (
                      <li key={key} className="flex justify-between items-center">
                        <span className="text-foreground/80 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                        <span className={`font-semibold ${key.toLowerCase().includes('start') ? 'text-green-600 dark:text-green-400' : key.toLowerCase().includes('end') || key.toLowerCase().includes('last') ? 'text-red-600 dark:text-red-400' : 'text-primary'}`}>{value}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </>
        );
      case "result":
      case "admit-card":
      case "answer-key":
      case "syllabus":
        return (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
               <DetailItemCard title={currentLabels.category} value={type.replace('-', ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')} icon={<Info />} />
               {item.date && <DetailItemCard title={currentLabels.date} value={item.date} icon={<CalendarDays />} />}
            </div>
            <Card className="mb-6 glassmorphism-card">
              <CardHeader><CardTitle className="gradient-text">{currentLabels.details}</CardTitle></CardHeader>
              <CardContent><p className="text-foreground/80 whitespace-pre-line">{item.description}</p></CardContent>
            </Card>
            {item.details && Array.isArray(item.details) && (
              <Card className="glassmorphism-card">
                <CardHeader><CardTitle className="gradient-text">{currentLabels.overview}</CardTitle></CardHeader>
                <CardContent>
                  <ul className="list-disc pl-5 space-y-2 text-foreground/80">
                    {item.details.map((detail, i) => <li key={i}>{detail}</li>)}
                  </ul>
                </CardContent>
              </Card>
            )}
          </>
        );
      default:
        return <p className="text-destructive">Invalid item type.</p>;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="py-12 bg-gradient-to-br from-purple-50 via-orange-50 to-teal-50 dark:from-slate-900 dark:via-zinc-900 dark:to-neutral-900"
    >
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <Button variant="outline" onClick={() => navigate(-1)} className="flex items-center gap-2 group hover:bg-primary/10 border-primary text-primary">
            <ArrowLeft className="h-5 w-5 group-hover:text-primary transition-transform group-hover:-translate-x-1" />
            <span className="font-semibold">{currentLabels.back}</span>
          </Button>
        </div>

        <Card className="mb-8 shadow-xl glassmorphism-card overflow-hidden">
          <div className={`p-6 bg-gradient-to-r ${type === 'job' ? 'from-primary to-accent' : type === 'admit-card' ? 'from-yellow-500 to-orange-500' : type === 'result' ? 'from-green-500 to-emerald-500' : 'from-secondary to-orange-400'} text-white`}>
            <div className="flex justify-between items-start mb-3">
              <Badge variant="secondary" className="bg-white/20 text-white backdrop-blur-sm">
                {type.replace('-', ' ').toUpperCase()}
              </Badge>
              {item.isNew && type === 'job' && <Badge variant="destructive" className="animate-subtle-pulse">NEW</Badge>}
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-3">{item.title}</h1>
            {item.organization && <p className="text-lg opacity-90">{item.organization}</p>}
          </div>
          
          <CardContent className="p-6">
            <LinkButtonGroup item={item} type={type} currentLabels={currentLabels} />
            <div className="flex flex-wrap gap-3 mt-4">
              <Button variant="outline" onClick={handleBookmark} className="border-primary text-primary hover:bg-primary/10">
                {isBookmarked ? currentLabels.bookmarked : currentLabels.bookmark} <Bookmark className={`ml-2 h-4 w-4 ${isBookmarked ? "fill-primary" : ""}`} />
              </Button>
              <Button variant="outline" onClick={handleShare} className="border-secondary text-secondary hover:bg-secondary/10">
                {currentLabels.share} <Share2 className="ml-2 h-4 w-4" />
              </Button>
            </div>
            <Separator className="my-6" />
            {renderContent()}
          </CardContent>
        </Card>

        <Card className="glassmorphism-card">
          <CardHeader className="flex-row items-center gap-3">
            <AlertTriangle className="h-8 w-8 text-yellow-500" />
            <CardTitle className="text-yellow-600 dark:text-yellow-400 !text-xl">{currentLabels.disclaimer}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
             {currentLabels.disclaimerText}
            </p>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
};

export default JobDetailPage;