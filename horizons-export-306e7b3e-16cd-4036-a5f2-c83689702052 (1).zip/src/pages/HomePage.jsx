import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Briefcase, FileText, CheckCircle, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { jobsData } from "@/data/jobsData";
import { updatesData } from "@/data/updatesData";
import { SectionWrapper, SectionHeader } from "@/components/PageElements";
import TestimonialCard from "@/components/TestimonialCard";

const ThreeColumnCard = ({ item, type, language }) => {
  const navigate = useNavigate();
  const handleClick = () => navigate(`/item/${type}/${item.id}`);

  const title = language === 'hi' && item.title_hi ? item.title_hi : item.title;
  const postedDateLabel = language === 'hi' ? 'प्रारंभ तिथि' : 'Start Date';
  const lastDateLabel = language === 'hi' ? 'अंतिम तिथि' : 'Last Date';
  
  let startDate = item.postedDate || (item.importantDates && item.importantDates.applicationStart) || item.date;
  let lastDate = item.lastDate || (item.importantDates && item.importantDates.applicationEnd);

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      viewport={{ once: true }}
      className="border-b border-dashed border-gray-300 dark:border-gray-700 py-3 hover:bg-opacity-20 dark:hover:bg-opacity-20 transition-colors duration-200 rounded-md px-2 -mx-2 cursor-pointer"
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyPress={(e) => e.key === 'Enter' && handleClick()}
    >
      <h4 className="font-semibold text-sm text-primary hover:underline mb-1 leading-tight">{title}</h4>
      <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs">
        {startDate && <span className="text-green-600 dark:text-green-400"><span className="font-medium">{postedDateLabel}:</span> {startDate}</span>}
        {lastDate && <span className="text-red-600 dark:text-red-400"><span className="font-medium">{lastDateLabel}:</span> {lastDate}</span>}
      </div>
    </motion.div>
  );
};

const Column = ({ title, items, type, emptyText, language, columnBgClass, columnHeaderClass }) => (
  <Card className={`glassmorphism-card flex-1 min-w-[280px] lg:min-w-0 overflow-hidden ${columnBgClass}`}>
    <CardHeader className={`rounded-t-xl py-4 px-5 ${columnHeaderClass}`}>
      <CardTitle className="text-xl font-bold flex items-center">
        {type === 'job' && <Briefcase className="mr-2 h-5 w-5"/>}
        {type === 'admit-card' && <FileText className="mr-2 h-5 w-5"/>}
        {type === 'result' && <CheckCircle className="mr-2 h-5 w-5"/>}
        {title}
      </CardTitle>
    </CardHeader>
    <CardContent className="pt-4 space-y-1 h-[600px] overflow-y-auto px-3 pb-3">
      {items.length > 0 ? items.map(item => (
        <ThreeColumnCard key={`${type}-${item.id}`} item={item} type={type} language={language} />
      )) : <p className="text-center text-muted-foreground py-10">{emptyText}</p>}
    </CardContent>
  </Card>
);

const HeroSlogan = ({ language, labels }) => {
  const currentLabels = labels[language];
  const sloganParts = currentLabels.heroSubtitle.split(':');
  const brandName = sloganParts[0] + ":";
  const restOfSlogan = sloganParts.slice(1).join(':').trim().split('.');
  
  const segments = restOfSlogan[0].split(' - ');

  return (
    <motion.p
      className="hero-slogan-base"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
    >
      <span className="hero-slogan-brand">{brandName}</span>
      <span className="hero-slogan-segment1"> {segments[0]}</span> -
      <span className="hero-slogan-segment2"> {segments[1]}</span>.
      <span className="hero-slogan-segment3"> {restOfSlogan[1]}.</span>
      <span className="hero-slogan-segment4"> {restOfSlogan.slice(2).join('.')}</span>
    </motion.p>
  );
};


const HomePage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [language, setLanguage] = useState(localStorage.getItem("language") || "en");

  useEffect(() => {
    document.title = language === 'hi' 
      ? "सरकारी नौकरियां - JOBS.SCHOOLHUNT.IN" 
      : "Sarkari Jobs - JOBS.SCHOOLHUNT.IN";
    
    const handleAppSearch = (event) => setSearchQuery(event.detail);
    const handleLangChange = (event) => setLanguage(event.detail);

    window.addEventListener('appSearch', handleAppSearch);
    window.addEventListener('languageChange', handleLangChange);

    return () => {
      window.removeEventListener('appSearch', handleAppSearch);
      window.removeEventListener('languageChange', handleLangChange);
    };
  }, [language]);

  const filterData = (data, query, typeCheck = () => true) => {
    const lowerQuery = query.toLowerCase();
    return data.filter(item => 
      (item.title.toLowerCase().includes(lowerQuery) || 
      (item.title_hi && item.title_hi.toLowerCase().includes(lowerQuery)) ||
      (item.organization && item.organization.toLowerCase().includes(lowerQuery))) &&
      typeCheck(item)
    ).slice(0, 25);
  };

  const allJobs = jobsData.map(j => ({...j, type: 'job'}));
  const allUpdates = updatesData;

  const filteredJobs = filterData(allJobs, searchQuery);
  const filteredResults = filterData(allUpdates, searchQuery, u => u.type === 'result');
  const filteredAdmitCards = filterData(allUpdates, searchQuery, u => u.type === 'admit-card');

  const labels = {
    en: {
      heroTitle: "Sarkari Naukri",
      heroSubtitle: "JOBS.SCHOOLHUNT.IN: From Education to Employment - In One Click. Get the latest updates on government jobs, results, admit cards, and more.",
      searchPlaceholder: "Search for jobs, results, admit cards...",
      latestJobs: "Latest Jobs",
      admitCards: "Admit Cards",
      results: "Results",
      feedbackTitle: "User Feedback",
      feedbackSub: "What our users say about us.",
      noJobs: "No jobs found matching your search.",
      noAdmitCards: "No admit cards found matching your search.",
      noResults: "No results found matching your search.",
    },
    hi: {
      heroTitle: "सरकारी नौकरी",
      heroSubtitle: "JOBS.SCHOOLHUNT.IN: शिक्षा से रोजगार तक - एक क्लिक में। सरकारी नौकरियों, परिणामों, प्रवेश पत्रों, और अधिक पर नवीनतम अपडेट प्राप्त करें।",
      searchPlaceholder: "नौकरियां, परिणाम, प्रवेश पत्र खोजें...",
      latestJobs: "नवीनतम नौकरियां",
      admitCards: "प्रवेश पत्र",
      results: "परिणाम",
      feedbackTitle: "उपयोगकर्ता प्रतिक्रिया",
      feedbackSub: "हमारे उपयोगकर्ता हमारे बारे में क्या कहते हैं।",
      noJobs: "आपकी खोज से मेल खाने वाली कोई नौकरी नहीं मिली।",
      noAdmitCards: "आपकी खोज से मेल खाने वाला कोई प्रवेश पत्र नहीं मिला।",
      noResults: "आपकी खोज से मेल खाने वाला कोई परिणाम नहीं मिला।",
    }
  };
  const currentLabels = labels[language];

  const testimonials = [
    { id: 1, name: "Ravi K.", text: currentLabels.feedbackSub === labels.hi.feedbackSub ? "यहाँ मेरी सपनों की नौकरी मिली! अपडेट बहुत तेज़ हैं।" : "Found my dream job here! Updates are super fast.", avatar: "RK" },
    { id: 2, name: "Priya S.", text: currentLabels.feedbackSub === labels.hi.feedbackSub ? "प्रवेश पत्र अलर्ट ने मुझे बचाया। अत्यधिक अनुशंसित!" : "The admit card alerts saved me. Highly recommended!", avatar: "PS" },
    { id: 3, name: "Amit G.", text: currentLabels.feedbackSub === labels.hi.feedbackSub ? "स्पष्ट पाठ्यक्रम और परिणाम। सरकारी नौकरियों के लिए सबसे अच्छी साइट।" : "Clear syllabus and results. Best site for govt jobs.", avatar: "AG" },
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
      <SectionWrapper id="hero" className="bg-gradient-to-b from-primary/10 via-secondary/5 to-background pt-12 md:pt-16">
        <div className="text-center">
          <motion.h1
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            {currentLabels.heroTitle.split(" ").slice(0,-1).join(" ")} <span className="gradient-text">{currentLabels.heroTitle.split(" ").pop()}</span>
          </motion.h1>
          
          <HeroSlogan language={language} labels={labels} />

          <motion.div
            className="max-w-xl mx-auto mb-10"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <div className="relative">
              <Input
                type="search"
                placeholder={currentLabels.searchPlaceholder}
                className="w-full p-4 pr-12 text-base rounded-full shadow-xl border-2 border-primary/50 focus:border-primary focus:ring-primary focus:ring-offset-2 dark:bg-slate-800 dark:text-white dark:placeholder-slate-400"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 h-6 w-6 text-primary/70" />
            </div>
          </motion.div>
        </div>
      </SectionWrapper>

      <SectionWrapper id="main-content-area" className="pt-0">
        <div className="flex flex-col lg:flex-row gap-6">
          <Column 
            title={currentLabels.latestJobs} 
            items={filteredJobs} 
            type="job" 
            emptyText={currentLabels.noJobs} 
            language={language}
            columnBgClass="column-bg-jobs hover:bg-blue-100 dark:hover:bg-blue-900/50"
            columnHeaderClass="column-header-jobs"
          />
          <Column 
            title={currentLabels.admitCards} 
            items={filteredAdmitCards} 
            type="admit-card" 
            emptyText={currentLabels.noAdmitCards} 
            language={language}
            columnBgClass="column-bg-admit-cards hover:bg-yellow-100 dark:hover:bg-yellow-900/50"
            columnHeaderClass="column-header-admit-cards"
          />
          <Column 
            title={currentLabels.results} 
            items={filteredResults} 
            type="result" 
            emptyText={currentLabels.noResults} 
            language={language}
            columnBgClass="column-bg-results hover:bg-green-100 dark:hover:bg-green-900/50"
            columnHeaderClass="column-header-results"
          />
        </div>
      </SectionWrapper>

      <SectionWrapper id="feedback" className="bg-accent/5 dark:bg-accent/10">
        <SectionHeader title={currentLabels.feedbackTitle.split(" ")[0]} gradientTitle={currentLabels.feedbackTitle.split(" ")[1]} subtitle={currentLabels.feedbackSub} />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <TestimonialCard key={testimonial.id} testimonial={testimonial} />
          ))}
        </div>
      </SectionWrapper>
    </motion.div>
  );
};

export default HomePage;