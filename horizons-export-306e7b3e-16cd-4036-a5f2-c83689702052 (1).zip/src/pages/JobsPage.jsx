import React from "react";
const JobsPage = () => {
  return (
    <div>
      <h1>Jobs Page (To be refactored or removed if not used in single-page design)</h1>
    </div>
  );
};
export default JobsPage;