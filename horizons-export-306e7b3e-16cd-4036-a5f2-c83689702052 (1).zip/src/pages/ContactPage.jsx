import React from "react";
const ContactPage = () => {
  return (
    <div>
      <h1>Contact Page (To be refactored or removed if not used in single-page design)</h1>
    </div>
  );
};
export default ContactPage;